Traxxas charge indicator by canomod on Thingiverse: https://www.thingiverse.com/thing:3617959

Summary:
Plug are to insert in your Traxxas battery to remember it status :• Full charge• Store charge• Empty